**Description**
A clear and concise description of what the bug is and what you would expect the behavior to be.

**Closes issue(s)**

**How to test / repro**

**Changes include**
- [ ] Bugfix (non-breaking change that solves an issue)
- [ ] New feature (non-breaking change that adds functionality)

**Screenshots / email client tests**
- [ ] I have tested this code in the following email clients: (list them here)
